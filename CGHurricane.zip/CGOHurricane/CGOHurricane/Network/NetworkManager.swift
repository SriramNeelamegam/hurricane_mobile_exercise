//
//  NetworkManager.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 06/03/23.
//


import Foundation
import UIKit

class NetworkManager {
    
    static let shared = NetworkManager()
    
    var activityIndicator : UIActivityIndicatorView?
    
    typealias SuccessHandler = (_ json : Any) -> ()
    typealias ErrorHandler = (_ error : Error) -> ()
    
    lazy var defaultSession:URLSession = {
        
        let config = URLSessionConfiguration.default
        config.httpAdditionalHeaders = ["Content-Type":"application/json; charset=UTF-8"]
        return URLSession(configuration: config, delegate: nil, delegateQueue: nil)
        
    }()
    
    func getRequest(urlString:String,
                    view:UIView,
                    success: @escaping (SuccessHandler),
                    failure: @escaping (ErrorHandler)) {
        
        showProgressView(in: view)
        
        let urlRequest = URLRequest(url: URL(string: urlString)!)
        
        let task = defaultSession.dataTask(with: urlRequest, completionHandler: { (data,response,error) -> () in
            
            self.hideProgressView()
            
            guard error == nil else {
                failure(error!)
                return
            }
            
            if let aData = data,
               let urlResponse = response as? HTTPURLResponse,
               (200..<300).contains(urlResponse.statusCode) {
                
                do {
                    let responseJSON = try JSONSerialization.jsonObject(with: aData, options: [])
                    success(aData)
                }
                catch let error as NSError {
                    failure(error)
                }
            }
        })
        task.resume()
        
    }
    
    
    func showProgressView(in view:UIView) {
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator?.frame = view.bounds
        activityIndicator?.color = .blue
        if let progressBar = activityIndicator{
            view.addSubview(progressBar)
        }
        activityIndicator?.startAnimating()
    }
    
    func hideProgressView() {
        DispatchQueue.main.async {
            self.activityIndicator?.stopAnimating()
            self.activityIndicator?.removeFromSuperview()
        }
    }
    
    
    
}
