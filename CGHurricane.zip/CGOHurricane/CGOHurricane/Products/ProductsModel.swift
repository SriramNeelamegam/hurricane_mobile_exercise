//
//  ProductsModel.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 08/03/23.
//


import Foundation

// MARK: - SampleJSON
struct ProductsModel: Codable {
    let lang: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let products: [Product]
}

// MARK: - Product
struct Product: Codable {
    let productName: String
    var productDescription:String?
    let productURL: String
    var productImageLandscape: String?

    enum CodingKeys: String, CodingKey {
        case productName = "product-name"
        case productDescription = "product-description"
        case productURL = "product-url"
        case productImageLandscape = "product-image-landscape"
    }
}



