//
//  ProductsViewController.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 08/03/23.
//

import UIKit

class ProductsViewController: UIViewController {
    
    @IBOutlet weak var productImgVw: UIImageView!
    @IBOutlet weak var productNameLbl: UILabel!
    @IBOutlet weak var productDesclbl: UILabel!
    var productURL:String?
    var productDetailURL:String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        
        
        NetworkManager.shared.getRequest(urlString: productURL ?? "", view: view) { json in
            print(json)
            let decoder = JSONDecoder()
            do {
                let newsResponse = try decoder.decode(ProductsModel.self, from: json as! Data)
                let url = URL(string: newsResponse.data.products[0].productImageLandscape ?? "")
                self.productDetailURL = newsResponse.data.products[0].productURL
                if url != nil{
                    if let data = try? Data(contentsOf: url!)
                    {
                        DispatchQueue.main.async {
                            let image: UIImage = UIImage(data: data) ?? UIImage(named: "sample")!
                            self.productImgVw.image = image
                            self.productNameLbl.text = newsResponse.data.products[0].productName
                            self.productDesclbl.text = newsResponse.data.products[0].productDescription
                        }
                    }
                }else{
                    DispatchQueue.main.async {
                        let image: UIImage = UIImage(named: "sample")!
                        self.productImgVw.image = image
                        self.productNameLbl.text = newsResponse.data.products[0].productName
                        self.productDesclbl.text = newsResponse.data.products[0].productDescription
                    }
                }
                
                
            }
            catch {
                //error handle
            }
        } failure: { error in
            print(error)
        }
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func didClickBackBtn(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func didClickProductImageBtn(_ sender: UIButton) {
        let webVC = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController") as? WebViewController
        webVC?.productURL = productDetailURL
        self.navigationController?.pushViewController(webVC!, animated: true)
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
