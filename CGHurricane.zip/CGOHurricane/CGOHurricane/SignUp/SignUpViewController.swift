//
//  SignUpViewController.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 06/03/23.
//

import UIKit
import CoreData

class SignUpViewController: UIViewController {

    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var pswrdField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    
    var loginArr:NSMutableArray = []
    var validFields = ValidateFields()
    
    override func viewDidLoad() {
        super.viewDidLoad()


        // Do any additional setup after loading the view.
    }
    
    @IBAction func didClickSubmitBtn(_ sender: UIButton) {
        if validFields.isValidUsername(Username: nameField.text!) != true{
            showAlert(withTitle: "Alert", withMessage: "Please check the UserName")
        }else if validFields.isValidPassword(password: pswrdField.text!) != true{
            showAlert(withTitle: "Alert", withMessage: "Please check the Password")
        }else if validFields.isValidMailInput(input: emailField.text!) != true{
            showAlert(withTitle: "Alert", withMessage: "Please check the Email")
        }else{
            saveData()
        }
    }
    
    func saveData(){
       
        let app = UIApplication.shared.delegate as! AppDelegate
        
        let context = app.persistentContainer.viewContext
        
        let userInfo = NSEntityDescription.insertNewObject(forEntityName: "LoginInfo", into: context)
        
        userInfo.setValue(nameField.text, forKey: "userName")
        userInfo.setValue(emailField.text, forKey: "email")
        userInfo.setValue(pswrdField.text, forKey: "password")
        
        do
        {
            try context.save()
            print("Registered  Sucessfully")
            
            let alert = UIAlertController(title: "Success", message: "Registered Sucessfully", preferredStyle: .alert)
                
                 let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
                     
                     let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
                     self.navigationController?.pushViewController(loginVC!, animated: true)
                     
                 })
                 alert.addAction(ok)
                 DispatchQueue.main.async(execute: {
                    self.present(alert, animated: true)
            })
            
        }
        catch
        {
            let Fetcherror = error as NSError
            print("error", Fetcherror.localizedDescription)
        }
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}




