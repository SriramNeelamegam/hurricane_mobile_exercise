//
//  HomeModel.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 07/03/23.
//


import Foundation

// MARK: - SampleJSON
struct HomeModel: Codable {
    var lang: String?
    var categories: [Category]?
}

// MARK: - Category
struct Category: Codable {
    let categoryName: String
    let products: [Products]

    enum CodingKeys: String, CodingKey {
        case categoryName = "category-name"
        case products
    }
}

// MARK: - Product
struct Products: Codable {
    let productName: String
    let productDetails: String
    let category: String

    enum CodingKeys: String, CodingKey {
        case productName = "product-name"
        case productDetails = "product-details"
        case category
    }
}
