//
//  HomeViewController.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 06/03/23.
//

import UIKit
import Foundation


class HomeViewController: UIViewController {

    var activityView: UIActivityIndicatorView?
    
    @IBOutlet weak var tblView: UITableView!
    var productDet = HomeModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true

        tblView.register(UINib(nibName: "HomeTableCell", bundle: nil), forCellReuseIdentifier: "HomeTableCell")

        
        NetworkManager.shared.getRequest(urlString: "https://av.sc.com/sg/rtob/categories.json", view: view) { json in
            print(json)
            let decoder = JSONDecoder()
            do {
                self.productDet = try decoder.decode(HomeModel.self, from: json as! Data)
                print(self.productDet)
                DispatchQueue.main.async {
                    self.tblView.reloadData()
                }
            }
            catch {
                //error handle
            }
        } failure: { error in
            print(error)
        }

    
        // Do any additional setup after loading the view.
    }
    

    
    
    func showActivityIndicator() {
        activityView = UIActivityIndicatorView(style: .large)
        activityView?.center = self.view.center
        self.view.addSubview(activityView!)
        activityView?.startAnimating()
    }

    func hideActivityIndicator(){
        if (activityView != nil){
            activityView?.stopAnimating()
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return productDet.categories?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productDet.categories?[section].products.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeTableCell", for:indexPath) as! HomeTableCell
        cell.productsLbl.text = productDet.categories?[indexPath.section].products[indexPath.row].productName
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return productDet.categories?[section].categoryName
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        if let header = view as? UITableViewHeaderFooterView {
            header.textLabel!.font = UIFont.boldSystemFont(ofSize: 18)
            header.textLabel?.frame = header.bounds
            header.textLabel?.textColor = UIColor.orange
            header.textLabel?.textAlignment = .center
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let productVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsViewController") as? ProductsViewController
        productVC?.productURL = productDet.categories?[indexPath.section].products[indexPath.row].productDetails
        self.navigationController?.pushViewController(productVC!, animated: true)
    }
    
    
}
