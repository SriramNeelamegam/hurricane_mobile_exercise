//
//  WebViewController.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 09/03/23.
//

import UIKit
import WebKit

class WebViewController: UIViewController {

    var productURL:String?
    @IBOutlet weak var webView: WKWebView!
    var nwManager = NetworkManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.navigationDelegate = self
        let url = URL(string: productURL ?? "")
        let requestObj = URLRequest(url: url! as URL)
        webView.load(requestObj)
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func didClickBackBtn(_ sender: UIButton) {
        webView.removeFromSuperview()
        self.navigationController?.popViewController(animated: true)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension WebViewController: WKNavigationDelegate{

    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        nwManager.showProgressView(in: self.view)
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        nwManager.hideProgressView()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        nwManager.hideProgressView()
    }
    
    
}
