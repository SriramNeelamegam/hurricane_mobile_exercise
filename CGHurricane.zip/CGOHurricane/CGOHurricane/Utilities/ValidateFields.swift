//
//  ValidateFields.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 08/03/23.
//

import Foundation
import UIKit

class ValidateFields {
    
    func isValidMailInput(input: String) -> Bool {
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: input)
    }
    
    func isValidUsername(Username:String) -> Bool {
        let RegEx = "[A-Z0-9a-z]{3,8}"
        let Test = NSPredicate(format:"SELF MATCHES %@", RegEx)
        return Test.evaluate(with: Username)
    }

    func isValidPassword(password: String) -> Bool {
        let passwordRegEx = "^(?=.*[a-z])[A-Za-z\\d$@$#!%*?&]{6,16}\\s*"
        let passwordTest = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
        let result = passwordTest.evaluate(with: password)
        return result
    }
    
}

extension UIViewController {

    func showAlert(withTitle title: String, withMessage message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
       
        let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
        })
        alert.addAction(ok)
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }
}
