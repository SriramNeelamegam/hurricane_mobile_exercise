//
//  LoginViewController.swift
//  CGOHurricane
//
//  Created by Sriram Neelamegam on 06/03/23.
//

import UIKit
import CoreData

class LoginViewController: UIViewController {

    
    @IBOutlet weak var userNameField: UITextField!
    
    @IBOutlet weak var pswrdField: UITextField!
    var result = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true

        // Do any additional setup after loading the view.
    }
    
    @IBAction func didClickSubmitBtn(_ sender: UIButton) {
        
        CheckForUserNameAndPasswordMatch(username: userNameField.text ?? "", password: pswrdField.text ?? "")
        
    }
    
    
    func CheckForUserNameAndPasswordMatch( username: String, password : String)
    {
        let app = UIApplication.shared.delegate as! AppDelegate

        let context = app.persistentContainer.viewContext
        
        let fetchrequest = NSFetchRequest<NSFetchRequestResult>(entityName: "LoginInfo")

        let predicate = NSPredicate(format: "userName = %@", username)

        fetchrequest.predicate = predicate
        do
        {
            result = try context.fetch(fetchrequest) as NSArray

            if result.count>0
            {
                let objectentity = result.firstObject as! LoginInfo
                
                if objectentity.userName == username && objectentity.password == password
                {
                    print("Login Succesfully")
                    let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController
                    self.navigationController?.pushViewController(homeVC!, animated: true)
                }
                else
                {
                    showAlert(withTitle: "Alert", withMessage: "Please check the credentials")
                }
            }
        }

        catch
        {
            let fetch_error = error as NSError
            print("error", fetch_error.localizedDescription)
        }

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
